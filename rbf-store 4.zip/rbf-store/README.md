# Real Body Fighter: store package
Files: index.html, manifest.webmanifest, sw.js, icon-192/512.png, privacy.html, terms.html.

## 1. Before publishing (do once)
- Replace [your email] and [date] in index.html, privacy.html, terms.html.
- Host everything on https (GitHub Pages, Netlify or Cloudflare Pages). The camera needs https.
- Self-host the libraries so the app works offline and no third party sees your players:
  curl -O https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
  curl -O https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/vision_bundle.mjs
  curl -O https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task
  (also copy the wasm folder from the same npm package), then change the URLs in index.html and the privacy text.
- Link privacy.html as your Privacy Policy URL in every store.

## 2. Google Play
- PWABuilder (pwabuilder.com) turns your https URL into an Android package. Upload the .aab.
- Data safety form: no data collected or shared; camera used on device only. Content rating questionnaire. Target audience 13+ (not a kids app).
- Add the assetlinks.json PWABuilder gives you at /.well-known/ on your site.
- New personal accounts: 12 testers for 14 days before production.

## 3. Apple App Store / other
- Apple rejects thin website wrappers: wrap with Capacitor, add camera usage text (NSCameraUsageDescription), and offer app features beyond the website.
- Samsung Galaxy Store, Amazon Appstore: same Android package. itch.io: zip of the folder. Web portals: they have their own rules.

## 4. Money and rules
- No ads, purchases or data collection are in this version, so privacy forms stay simple.
- Ads: use a consent tool (Google UMP), and no personalised ads for under 18s. Purchases: Google Play Billing / Apple IAP.
- Do not pay players real money. Use coins and cosmetics only.
- Keep the safety check, health notice, break reminders and Delete my data button: stores and regulators look for them.
